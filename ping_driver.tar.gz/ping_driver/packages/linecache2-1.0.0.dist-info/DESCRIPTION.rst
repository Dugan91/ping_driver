A backport of linecache to older supported Pythons.

 >>> import linecache2 as linecache

Profit.



