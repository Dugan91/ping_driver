Library for retrieving information about catkin packages.


