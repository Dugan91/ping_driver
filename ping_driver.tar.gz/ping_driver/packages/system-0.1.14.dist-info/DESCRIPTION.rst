System utility functions.


